﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CalculatorApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<string> OperationList = new List<string>{" ", "+", "-", "*", "/"};
        List<History> HistoryList = new List<History>();
        Stack<float> InputStack = new Stack<float>();
        Stack<float> memoryStack = new Stack<float>();
        string operation;

        private class History
        {
            public string Action { get; set; }
            public string Value { get; set; }
        }
        public MainWindow()
        {
            InitializeComponent();
            this.Load();
        }

        private void Load()
        {
            if (System.Diagnostics.Process.GetProcessesByName(System.IO.Path.GetFileNameWithoutExtension(System.Reflection.Assembly.GetEntryAssembly().Location)).Count() > 1)
            {
                System.Diagnostics.Process.GetCurrentProcess().Kill();
            }

            this.Operation_ComboBox.ItemsSource = OperationList;
        }

        private void InputDisplay_TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            string inputKey = e.Text == "\r" ? "=" : e.Text;

            InitializeDisplay(inputKey);

            if (Regex.IsMatch(inputKey, "[-+/*=]"))
            {
                if (InputStack.Count > 0)
                {
                    PerformOperation();
                }
                else
                {
                    if (!string.IsNullOrEmpty(this.InputDisplay_TextBox.Text))
                        InputStack.Push(float.Parse(this.InputDisplay_TextBox.Text));
                }

                try
                {
                    this.Equation_TextBox.Text = InputStack.Peek().ToString() + " " + inputKey;
                    operation = inputKey;
                    this.InputDisplay_TextBox.Text = operation == "=" ? InputStack.Peek().ToString() : string.Empty;
                }
                catch
                {
                    // Do nothing
                }

            }
            e.Handled = Regex.IsMatch(e.Text, "[^0-9.]+");
        }

        private void InitializeDisplay(string inputKey)
        {
            if (operation == "=")
            {
                this.InputDisplay_TextBox.Text = string.Empty;
                operation = inputKey;
            }
        }

        private void PerformOperation()
        {
            if (this.InputDisplay_TextBox.Text == string.Empty)
            {
                return;
            }

            float num1 = InputStack.Pop();
            switch (operation)
            {
                case "+":
                    InputStack.Push(num1 + float.Parse(this.InputDisplay_TextBox.Text));
                    HistoryList.Add(new History
                    {
                        Action = "Add",
                        Value = InputStack.Peek().ToString()
                    });
                    break;
                case "-":
                    InputStack.Push(num1 - float.Parse(this.InputDisplay_TextBox.Text));
                    HistoryList.Add(new History
                    {
                        Action = "Subtract",
                        Value = InputStack.Peek().ToString()
                    });
                    break;
                case "*":
                    InputStack.Push(num1 * float.Parse(this.InputDisplay_TextBox.Text));
                    HistoryList.Add(new History
                    {
                        Action = "Multiply",
                        Value = InputStack.Peek().ToString()
                    });
                    break;
                case "/":
                    if (float.Parse(this.InputDisplay_TextBox.Text) == 0)
                    {
                        System.Windows.MessageBox.Show("Cannot divide by zero.");
                        HistoryList.Add(new History
                        {
                            Action = "Equal",
                            Value = "Error"
                        });
                        InputStack.Push(num1);
                        break;
                    }
                    InputStack.Push(num1 / float.Parse(this.InputDisplay_TextBox.Text));
                    HistoryList.Add(new History
                    {
                        Action = "Divide",
                        Value = InputStack.Peek().ToString()
                    });
                    break;
                case "=":
                default:
                    InputStack.Push(float.Parse(this.InputDisplay_TextBox.Text));
                    HistoryList.Add(new History
                    {
                        Action = "Equal",
                        Value = InputStack.Peek().ToString()
                    });
                    InputStack.Push(num1);
                    break;
            }
        }

        private void Zero_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "0";
        }

        private void One_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "1";
        }

        private void Two_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "2";
        }

        private void Three_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "3";
        }

        private void Four_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "4";
        }

        private void Five_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "5";
        }

        private void Six_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "6";
        }

        private void Seven_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "7";
        }

        private void Eight_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "8";
        }

        private void Nine_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += "9";
        }

        private void Dot_Button_Click(object sender, RoutedEventArgs e)
        {
            InitializeDisplay(string.Empty);
            this.InputDisplay_TextBox.Text += ".";
        }

        private void Equal_Button_Click(object sender, RoutedEventArgs e)
        {
            TextCompositionEventArgs textCompositionEventArgs =
                new TextCompositionEventArgs(Keyboard.PrimaryDevice,
                new TextComposition(InputManager.Current, null, "="));

            textCompositionEventArgs.RoutedEvent = e.RoutedEvent;
            this.InputDisplay_TextBox_PreviewTextInput(sender, textCompositionEventArgs);
        }

        private void Operation_ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TextCompositionEventArgs textCompositionEventArgs =
                new TextCompositionEventArgs(Keyboard.PrimaryDevice,
                new TextComposition(InputManager.Current, null, this.Operation_ComboBox.SelectedItem.ToString()));

            textCompositionEventArgs.RoutedEvent = e.RoutedEvent;
            this.InputDisplay_TextBox_PreviewTextInput(sender, textCompositionEventArgs);

            this.Operation_ComboBox.SelectedIndex = 0;
        }

        private void CE_Button_Click(object sender, RoutedEventArgs e)
        {
            this.InputDisplay_TextBox.Text = string.Empty;
        }

        private void C_Button_Click(object sender, RoutedEventArgs e)
        {
            this.InputDisplay_TextBox.Text = string.Empty;
            this.Equation_TextBox.Text = string.Empty;
            InputStack.Clear();
        }

        private void CalculatorApp_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            string input = e.Key.ToString().Replace("NumPad", string.Empty).
                Replace("Add", "+").
                Replace("Subtract", "-").
                Replace("Multiply", "*").
                Replace("Divide", "/").
                Replace("Return", "=").
                Replace("Decimal", ".").
                Replace("OemPeriod", ".").
                Replace("OemPlus", "+").
                Replace("OemMinus", "-").
                Replace("NumLock", string.Empty).
                Replace("D", string.Empty).
                Replace("Oem3", string.Empty).
                Replace("F", string.Empty);

            if (!Regex.IsMatch(input, "[-+/*=0-9.]+") && input != "Back")
                return;

            TextCompositionEventArgs textCompositionEventArgs =
                new TextCompositionEventArgs(Keyboard.PrimaryDevice,
                new TextComposition(InputManager.Current, null, input));

            textCompositionEventArgs.RoutedEvent = e.RoutedEvent;
            this.InputDisplay_TextBox_PreviewTextInput(sender, textCompositionEventArgs);

            if (input == "Back")
            {
                DeleteLastChar();
            }
            else if (!Regex.IsMatch(input, "[-+/*=]"))
            {
                this.InputDisplay_TextBox.Text += input;
            }
        }

        private void DeleteLastChar()
        {
            try
            {
                string text = this.InputDisplay_TextBox.Text;
                this.InputDisplay_TextBox.Text = text.Remove(text.Length - 1);
            }
            catch
            {
                // Do Nothing
            }
        }

        private void PlusMinus_Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(this.InputDisplay_TextBox.Text))
            {
                this.InputDisplay_TextBox.Text += "-";
            }
            else
            {
                this.InputDisplay_TextBox.Text = (float.Parse(this.InputDisplay_TextBox.Text) * -1).ToString();
            }
        }

        private void Exit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Copy(object sender, RoutedEventArgs e)
        {
            System.Windows.Clipboard.SetText(this.InputDisplay_TextBox.Text);
        }

        private void Paste(object sender, RoutedEventArgs e)
        {
            this.InputDisplay_TextBox.Text = System.Windows.Clipboard.GetText();
        }

        private void Export(object sender, RoutedEventArgs e)
        {
            Stream fileStream;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "XML-File | *.xml";
            saveFileDialog.Title = "Save History Trail";

            if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if ((fileStream = saveFileDialog.OpenFile()) != null)
                {
                    StreamWriter sw = new StreamWriter(fileStream);
                    int i = 1;
                    foreach (History hist in HistoryList)
                    {
                        sw.WriteLine(i.ToString() + "\t" + hist.Action + "\t" + hist.Value);
                        i++;
                    }
                    sw.Close();
                    fileStream.Close();
                }
            }
        }

        private void Import(object sender, RoutedEventArgs e)
        {
            Stream fileStream;
            OpenFileDialog saveFileDialog = new OpenFileDialog();
            saveFileDialog.Filter = "XML-File | *.xml";
            saveFileDialog.Title = "Open History Trail";

            if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if ((fileStream = saveFileDialog.OpenFile()) != null)
                {
                    StreamReader sr = new StreamReader(fileStream);
                    HistoryList.Clear();
                    while (!sr.EndOfStream)
                    {
                        string line = sr.ReadLine();
                        string[] values = line.Split('\t');
                        HistoryList.Add(new History
                        {
                            Action = values[1],
                            Value = values[2]
                        });
                    }
                    sr.Close();
                    fileStream.Close();
                }
            }
        }

        private void MemClear_Button_Click(object sender, RoutedEventArgs e)
        {
            memoryStack.Clear();
        }

        private void MemRecall_Button_Click(object sender, RoutedEventArgs e)
        {
            this.InputDisplay_TextBox.Text = memoryStack.Peek().ToString();
        }

        private void MemPlus_Button_Click(object sender, RoutedEventArgs e)
        {
            memoryStack.Push(memoryStack.Count != 0 ?
                memoryStack.Peek() + float.Parse(this.InputDisplay_TextBox.Text) :
                float.Parse(this.InputDisplay_TextBox.Text));

            MemoryTrail_ListBox.ItemsSource = memoryStack;
            MemoryTrail_ListBox.Items.Refresh();
        }

        private void Delete_Button_Click(object sender, RoutedEventArgs e)
        {
            DeleteLastChar();
        }

        private void MemMinus_Button_Click(object sender, RoutedEventArgs e)
        {
            memoryStack.Push(memoryStack.Count != 0 ?
                memoryStack.Peek() - float.Parse(this.InputDisplay_TextBox.Text) :
                float.Parse(this.InputDisplay_TextBox.Text));

            MemoryTrail_ListBox.ItemsSource = memoryStack;
            MemoryTrail_ListBox.Items.Refresh();
        }
    }
}
